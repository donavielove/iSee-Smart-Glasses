#include <exception>
using namespace std;

#include "Camera_Shutter_Button2.h"
#include "Control_Panel_2.h"

void Camera_Shutter_Button2::capture() {
	throw "Not yet implemented";
}

void Camera_Shutter_Button2::distance() {
	throw "Not yet implemented";
}

void Camera_Shutter_Button2::New_Method_Created() {
	throw "Not yet implemented";
}
