#include <exception>
using namespace std;

#include "Control_Panel_2.h"
#include "Volume_Up2.h"
#include "Camera_Shutter_Button2.h"
#include "Phone2.h"
#include "Voice_Activation2.h"

void Control_Panel_2::voiceActivation() {
	throw "Not yet implemented";
}

void Control_Panel_2::cameraActivation() {
	throw "Not yet implemented";
}

