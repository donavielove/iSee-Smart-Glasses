#include <exception>
using namespace std;

#include "Emergency2.h"
#include "Voice_Activation2.h"

void Emergency2::callHelp() {
	throw "Not yet implemented";
}

void Emergency2::sendLocation() {
	throw "Not yet implemented";
}

void Emergency2::sendTest() {
	throw "Not yet implemented";
}

