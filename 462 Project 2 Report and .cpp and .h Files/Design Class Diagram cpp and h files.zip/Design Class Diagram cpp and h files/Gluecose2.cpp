#include <exception>
using namespace std;

#include "Gluecose2.h"
#include "Voice_Activation2.h"

void Gluecose2::calculateGluecose() {
	throw "Not yet implemented";
}

void Gluecose2::sendInfo() {
	throw "Not yet implemented";
}

