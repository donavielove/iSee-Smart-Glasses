#include <exception>
using namespace std;

#include "Phone2.h"
#include "Control_Panel_2.h"

void Phone2::sendLocation() {
	throw "Not yet implemented";
}

