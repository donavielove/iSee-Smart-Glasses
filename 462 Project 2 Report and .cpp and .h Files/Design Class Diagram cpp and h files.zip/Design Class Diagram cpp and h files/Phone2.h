#include <exception>
using namespace std;

#ifndef __Phone2_h__
#define __Phone2_h__

// #include "Control_Panel_2.h"

class Control_Panel_2;
class Phone2;

class Phone2
{
	private: On/Off _connectedLight;
	public: Control_Panel_2* _unnamed_Control_Panel_2_;

	public: void sendLocation();
};

#endif
