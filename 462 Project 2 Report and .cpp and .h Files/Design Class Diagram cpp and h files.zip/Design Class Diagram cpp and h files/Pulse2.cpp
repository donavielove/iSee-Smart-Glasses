#include <exception>
using namespace std;

#include "Pulse2.h"
#include "Voice_Activation2.h"

void Pulse2::calculatePulse() {
	throw "Not yet implemented";
}

void Pulse2::sendInfo() {
	throw "Not yet implemented";
}

