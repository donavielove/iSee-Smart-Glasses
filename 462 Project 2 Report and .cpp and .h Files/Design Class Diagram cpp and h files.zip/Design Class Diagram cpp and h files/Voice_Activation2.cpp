#include <exception>
using namespace std;

#include "Voice_Activation2.h"
#include "Gluecose2.h"
#include "Control_Panel_2.h"
#include "Emergency2.h"
#include "Pulse2.h"

void Voice_Activation2::callPulse() {
	throw "Not yet implemented";
}

void Voice_Activation2::callGluecose() {
	throw "Not yet implemented";
}

void Voice_Activation2::callEmergency() {
	throw "Not yet implemented";
}

