#include <exception>
using namespace std;

#include "Volume_Up2.h"
#include "Control_Panel_2.h"

void Volume_Up2::lowerVolumn() {
	throw "Not yet implemented";
}

void Volume_Up2::increaseVolumn() {
	throw "Not yet implemented";
}

