#include <exception>
using namespace std;

#ifndef __Volume_Up2_h__
#define __Volume_Up2_h__

// #include "Control_Panel_2.h"

class Control_Panel_2;
class Volume_Up2;

class Volume_Up2
{
	private: int _volume;
	private: int _volumne;
	public: Control_Panel_2* _unnamed_Control_Panel_2_;
	public: Control_Panel_2* _unnamed_Control_Panel_2_2;

	public: void lowerVolumn();

	public: void increaseVolumn();
};

#endif
