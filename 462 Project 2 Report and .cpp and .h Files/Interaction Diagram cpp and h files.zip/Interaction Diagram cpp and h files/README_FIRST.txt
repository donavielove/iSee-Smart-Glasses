README_FIRST
--------------------------------------------------------------------
Unfortunetly, Visual Paradigm would not allow us to export our 
interaction diagram into code due to the feature not being available
to Visual Paradigm Standard.
--------------------------------------------------------------------